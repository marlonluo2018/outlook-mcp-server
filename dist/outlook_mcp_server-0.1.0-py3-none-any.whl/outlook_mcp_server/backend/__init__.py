"""
Backend module for Outlook MCP Server.
"""